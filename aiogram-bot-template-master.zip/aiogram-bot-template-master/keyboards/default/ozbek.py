from aiogram.types import ReplyKeyboardMarkup, KeyboardButton

menu2 = ReplyKeyboardMarkup(
    keyboard=[
    [
        KeyboardButton(text='Dachalar ro`yxati'),
        KeyboardButton(text='Dachalarni izlash'),
    ],
    [
        KeyboardButton(text='Ortga'),
        KeyboardButton(text='Tilni o`zgartirish')
    ],
    ],
    resize_keyboard=True
)

menu4 = ReplyKeyboardMarkup(
    keyboard=[
        [
            KeyboardButton(text='Orqaga'),
        ],
    ],
    resize_keyboard=True
)