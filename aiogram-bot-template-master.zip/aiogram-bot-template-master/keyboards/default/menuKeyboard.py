from aiogram.types import ReplyKeyboardMarkup, KeyboardButton
from aiogram.types.reply_keyboard import ReplyKeyboardRemove

menu = ReplyKeyboardMarkup(
    keyboard = [
        [
            KeyboardButton(text = 'O`zbek tili'),
            KeyboardButton(text = 'Русский язик'),
        ],
    ],
    resize_keyboard=True
)
