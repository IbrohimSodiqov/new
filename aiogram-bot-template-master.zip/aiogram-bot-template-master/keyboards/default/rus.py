from aiogram.types import ReplyKeyboardMarkup, KeyboardButton

menu3 = ReplyKeyboardMarkup(
    keyboard=[
    [
        KeyboardButton(text='Каталог постов'),
        KeyboardButton(text='Искат посты'),
    ],
    [
        KeyboardButton(text='Назад'),
        KeyboardButton(text='Изменить язык')
    ],
    ],
    resize_keyboard=True
)
menu5 = ReplyKeyboardMarkup(
    keyboard=[
        [
            KeyboardButton(text='назад '),
        ],
    ],
    resize_keyboard=True
)