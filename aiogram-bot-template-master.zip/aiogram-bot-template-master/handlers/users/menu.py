from aiogram.dispatcher.filters import Command, Text
from aiogram.types import Message, ReplyKeyboardRemove, message
from keyboards.default.menuKeyboard import menu
from keyboards.default.ozbek import menu2
from keyboards.default.rus import menu3
from keyboards.default.ozbek import menu4
from keyboards.default.rus import menu5


from loader import dp

@dp.message_handler(Command("start"))

async def show_menu(message: Message):
    await message.answer(f"Salom, {message.from_user.full_name}!")
    await message.answer("Tilni tanlang, Выберите язык",reply_markup=menu)

@dp.message_handler(text='O`zbek tili')
async def send_link(message: Message):
    await message.answer("Til tanlandi",reply_markup=menu2)

@dp.message_handler(text='Русский язик')
async def send_link(message: Message):
    await message.answer("Выбран язык",reply_markup=menu3)

@dp.message_handler(text='Tilni o`zgartirish')
async def send_link(message: Message):
    await message.answer("Tilni tanlang, Выберите язык",reply_markup=menu)

@dp.message_handler(text='Ortga')
async def send_link(message: Message):
    await message.answer("Tilni tanlang, Выберите язык",reply_markup=menu)

@dp.message_handler(text='Dachalar ro`yxati')
async def send_link(message: Message):
    await message.reply(text="Dachalar ro`yxati bosh")

@dp.message_handler(text='Каталог постов')
async def send_link(message: Message):
    await message.reply(text="Сейчас нету")

@dp.message_handler(text='Изменить язык')
async def send_link(message: Message):
    await message.answer("Tilni tanlang, Выберите язык",reply_markup=menu)

@dp.message_handler(text='Назад')
async def send_link(message: Message):
    await message.answer("Tilni tanlang, Выберите язык",reply_markup=menu)

@dp.message_handler(text='Dachalarni izlash')
async def send_link(message: Message):
    await message.answer("Dacha egasini telefon raqamini kiriting:", reply_markup=menu4)

@dp.message_handler(text='Искат посты')
async def send_link(message: Message):
    await message.answer("Введите номер телефона владельца поста", reply_markup=menu5)

@dp.message_handler(text='Orqaga')
async def send_link(message: Message):
    await message.answer("Orqaga qaytildi", reply_markup=menu2)

@dp.message_handler(text='назад')
async def send_link(message: Message):
    await message.answer("назад выполнен", reply_markup=menu3)